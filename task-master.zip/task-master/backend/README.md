# Local Development Setup Guide

## Getting Started

### 1. Project Setup
1. Download the ZIP file
2. Extract it to your desired location
3. Open a terminal/command prompt in the extracted folder

### 2. Email Configuration
1. Locate the `settings.py` file in the task_manager directory
2. Create a copy and rename it to `.env`
3. Update the following credentials in `.env`:
```env
EMAIL_HOST_USER="youremail@gmail.com"
EMAIL_HOST_PASSWORD="your generated app password"
```

### 3. Virtual Environment Setup

#### Windows:
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
venv\Scripts\activate
```

#### macOS/Linux:
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
source venv/bin/activate
```

### 4. Install Dependencies
```bash
# Install required packages
pip install -r requirements.txt
```

### 5. Database Setup
```bash
# Generate database migrations
python manage.py makemigrations

# Apply migrations
python manage.py migrate
```

### 6. Run Development Server
```bash
python manage.py runserver
```

The application will be available at:
- 📱 Local: http://127.0.0.1:8000/api/docs/
- ⚙️ Admin: http://127.0.0.1:8000/admin/

## Troubleshooting

### Virtual Environment
- Ensure you see `(venv)` in your terminal prompt
- For Windows PowerShell permission issues:
  ```powershell
  Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
  ```

### Common Issues
- If `python` command isn't recognized, try `python3`
- For pip installation errors:
  ```bash
  python -m pip install --upgrade pip
  ```

## Additional Notes
- Keep the virtual environment activated during development
- To deactivate when finished:
  ```bash
  deactivate
  ```





# Google App Password Setup Guide

## Steps to Create Google App Password for Email

### 1. Enable 2-Step Verification
1. Go to your [Google Account](https://myaccount.google.com/)
2. Navigate to Security settings
3. Click on "2-Step Verification" under "Signing in to Google"
4. Follow the prompts to enable 2-Step Verification if not already enabled

### 2. Create App Password
1. Go to your [Google Account Settings](https://myaccount.google.com/)
2. Click on "Security" in the left navigation panel
3. Under "Signing in to Google," select "2-Step Verification"
4. Scroll to the bottom and select "App passwords"
5. Click "Select app" and choose "Mail" from the dropdown
6. Click "Select device" and choose your device type
7. Click "Generate"
8. Google will display a 16-character password

### 3. Using the App Password
1. Copy the 16-character password
2. Update your `.env` file with the new password:
```env
EMAIL_HOST_USER=your_email@gmail.com
EMAIL_HOST_PASSWORD=your_16_character_app_password
```

## Important Notes
- ⚠️ Store this password securely
- 🔒 Never share your app password
- 🔄 You can revoke app passwords at any time from your Google Account
- 📧 Use this password only for the specific application you created it for

## Troubleshooting

### Common Issues
- If you don't see "App passwords" option:
  - Ensure 2-Step Verification is enabled
  - Make sure you're fully signed into your Google Account
- If password isn't working:
  - Double-check for copying errors
  - Generate a new app password
  - Ensure you're using the correct email address

### Password Not Working?
1. Delete the existing app password
2. Generate a new one
3. Update your `.env` file with the new password
4. Restart your application

## Security Tips
- 🔐 Regularly review and revoke unused app passwords
- 🚫 Don't use your main Google Account password
- ✨ Generate unique app passwords for different applications
- 📱 Keep 2-Step Verification enabled at all times
